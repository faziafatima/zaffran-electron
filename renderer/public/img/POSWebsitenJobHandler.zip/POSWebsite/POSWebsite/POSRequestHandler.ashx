﻿<%@ WebHandler Language="C#" CodeBehind="POSRequestHandler.ashx.cs" Class="POSWebsite.POSRequestHandler" %>

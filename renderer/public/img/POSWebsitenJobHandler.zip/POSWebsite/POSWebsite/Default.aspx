﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="POSWebsite.Default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <a href="skype:echo123?call">Start skype call</a><br />
        <a href="POSMyApp:1234" >click to print order 1234</a><br />
        <a href="POSMyApp:4321" >click to print order 4321</a><br />
        <a href="POSMyApp:56789" >click to print order 56789</a><br />
        <a href="MyWebApp:www.techsapphire.in/TestDoc.docx" >Run Desktop App</a>
    </div>
    </form>
</body>
</html>

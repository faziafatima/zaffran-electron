﻿<%@ Application Codebehind="Global.asax.cs" Inherits="POSWebsite.Global" Language="C#" %>
